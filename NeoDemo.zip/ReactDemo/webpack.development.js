const target = 'https://crm-cd.xiaoshouyi.com'
module.exports = {
    target,
    web:{
        devServer: {
            port: 7900
        },
    }
}